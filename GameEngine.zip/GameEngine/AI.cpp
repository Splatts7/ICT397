/*
* Implementation of AI.cpp file
* Author - Jonathan Sands
*/

#include "AI.h"

// Default constructor
AI::AI()
{

}

// Deconstructor
AI::~AI()
{
	
}