-- Camera.lua
-- Script for initialization of the camera object
-- Author - Jack Matters
-- Date - 18/04/2017
camx=0.0
camy=0.0
camz=50.0
lookx=0.0
looky=0.0
lookz=-50.0
upx=0.0
upy=1.0
upz=0.0
rotspeed=1200.0
movespeed=2.0