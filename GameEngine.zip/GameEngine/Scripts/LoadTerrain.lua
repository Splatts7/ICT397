-- LoadTerrain.lua
-- Script for loading in of terrain maps
-- Author - Jack Matters
-- Date - 18/04/2017
numTerrain=1
method="BruteForce"
fileName=""
