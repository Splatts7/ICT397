/*
* Implementation of Animation.cpp file
* Author - Jonathan Sands
*/

#include "Animation.h"

// Default constructor
Animation::Animation()
{

}

// Deconstructor
Animation::~Animation()
{
	
}