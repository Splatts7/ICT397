-- GameSounds.lua
-- Script for loading in of game sounds
-- Author - Jack Matters
-- Date - 19/04/2017
sounds=
{
  a = "Sounds/scratch.wav",
  b = "Sounds/high.wav",
  c = "Sounds/medium.wav",
  d = "Sounds/low.wav"
}
numSounds=2

