/**
* @class Animation
* @brief Animation engine to handle all GameObject animations
* @author Jonathan Sands
* @version 01 - Started
* @date 23/04/2017
*/

#ifndef ANIMATION_H
#define ANIMATION_H

class Animation
{
	public:

		/**
		* @brief Defualt constructor
		*/
		Animation();

		/**
		* @brief Deconstructor
		*/
		~Animation();

	private:



};

#endif