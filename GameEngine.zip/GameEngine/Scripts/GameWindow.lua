-- GameWindow.lua
-- Script for creation of the game window
-- Author - Jack Matters
-- Date - 13/04/2017
width=1000
height=600
xposition=100
yposition=100