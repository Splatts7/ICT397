/**
* @class AI
* @brief AI engine to handle all game AI
* @author Jonathan Sands
* @version 01 - Started
* @date 23/04/2017
*/

#ifndef AI_H
#define AI_H

class AI
{
	public:

		/**
		* @brief Defualt constructor
		*/
		AI();

		/**
		* @brief Deconstructor
		*/
		~AI();

	private:



};

#endif